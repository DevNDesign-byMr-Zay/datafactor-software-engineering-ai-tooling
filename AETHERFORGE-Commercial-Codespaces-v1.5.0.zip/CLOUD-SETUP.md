# AETHERFORGE Commercial IDE for GitHub Codespaces

This verified source bundle is additive to the existing draft PR #211. It does not replace the maintained `src` directory or `apps/aetherforge-workbench` companion.

Install using the verified repo helper `python3 tools/import-aetherforge-commercial.py AETHERFORGE-Commercial-Codespaces-v1.5.0.zip` after uploading the ZIP to your Codespace folder. No installation or executing untrusted ZIP contents occurs outside this tool. Do not set Codespaces forwarded port 4546 to Public.

Run `node --test tests/aetherforge-commercial-cloud.test.mjs` and `bash .devcontainer/start-commercial.sh`. In the Codespaces Ports tab open Private port 4546.

Google Distroless Node 22 and Python 3.13 images must be preloaded. All project execution remains manual, Docker-only, network-disabled, read-only, unprivileged, resource-limited, and consent-gated.

GitHub PR #211 must retain draft status until the actual Codespaces deployment and physical browser QA have passed, and the source is committed with green CI.
